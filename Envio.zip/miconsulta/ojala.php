<?php 
$conn = pg_connect("host=localhost dbname=biblioteca user=postgres password=12345");
if (!$conn) {
  echo "An error occurred.\n";
  exit;
}

$result = pg_query($conn, "SELECT nombres, apellidos, id FROM autor");
if (!$result) {
  echo "An error occurred.\n";
  exit;
}
/*
while ($row = pg_fetch_assoc($result)) {
  echo $row['nombres'];
  echo $row['apellidos'];
  echo $row['id'];
}
*/

$arr = pg_fetch_assoc($result);
$salida = array();

while ($row = pg_execute($arr)) {

    array_push($salida, $row);
}

 



echo json_encode($arr);

?>