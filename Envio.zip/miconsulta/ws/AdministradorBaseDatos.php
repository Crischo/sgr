<?php

class AdministradorBaseDatos
{
    private $link;
 
    private function conectar()
    {
        
       
        $this->link=pg_connect("host=localhost dbname=biblioteca user=postgres password=12345");
        
        if (!$this->link) {
            echo "no mismo";
        }
        return $link;
        

       
    }
 
    private function consultar($sql)
    {

        $result = pg_query($link, $sql);
        $arr = pg_fetch_assoc($result);
        $salida = array();
        
        
                
        
         
        
        
        
        echo json_encode($arr);
        
    }
 


    private function desconectar()
    {
        pg_close($this->link);
    }

    public function ejecutarConsulta($sql){
        $this->conectar();
        $salida = $this->consultar($sql);
        $this->desconectar();
        return $salida;
    }
}